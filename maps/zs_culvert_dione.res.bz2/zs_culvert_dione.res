// .\de_storm.res - created with RESGen v1.00
// RESGen is made by Jeroen "ShadowLord" Bogers
// URL: http://www.unitedadmins.com/mapRESGEN.asp
// Res creation date, GMT timezone (dd-mm-yyyy): 08-06-2001

// .res entries:
clvt.wad
dm_tunnel.wad
zm_abyss.wad
zm_abyss2.wad
zs_anni.wad
zs_double.wad
zs_evolution.wad
models/gibs_cave.mdl
models/gibs_stairs.mdl
models/gibs_stairsmetal.mdl
models/null.mdl
