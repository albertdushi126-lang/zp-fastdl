// zp_sander.res - created with RESGen v2.0 BETA 3.
// RESGen is made by Jeroen "ShadowLord" Bogers.
// For more info go to http://resgen.hltools.com
// or E-mail me at resgen@hltools.com.

// .res entries (20):
gfx/env/zp_riversideup.tga
gfx/env/zp_riversidedn.tga
gfx/env/zp_riversidelf.tga
gfx/env/zp_riversidert.tga
gfx/env/zp_riversideft.tga
gfx/env/zp_riversidebk.tga
sprites/glow01.spr
models/dx/maps/light_03.mdl
models/dx/maps/light_04.mdl
models/dx/maps/bush_01.mdl
models/dx/maps/helicopter_down.mdl
sound/dx/maps/outside_loop.wav
sound/dx/maps/industrial.wav
sound/dx/maps/water_02.wav
sound/dx/maps/dist_explosion2.wav
sound/dx/maps/strange6.wav
models/dx/maps/light_02.mdl
models/dx/maps/tree_02b.mdl
models/dx/maps/tree_02a.mdl
models/dx/maps/bush_05.mdl
