// zm_train_beta3.res - created with RESGen v2.0 BETA 3.
// RESGen is made by Jeroen "ShadowLord" Bogers.
// For more info go to http://resgen.hltools.com
// or E-mail me at resgen@hltools.com.

// .res entries (19):
halflife.wad
cs_bdog.wad
decals.wad
hiubert777.wad
gfx/env/trainyardup.tga
gfx/env/trainyarddn.tga
gfx/env/trainyardlf.tga
gfx/env/trainyardrt.tga
gfx/env/trainyardft.tga
gfx/env/trainyardbk.tga
sprites/flare1.spr
sound/ambience/jetflyby1.wav
sound/ambience/wren1.wav
sound/ambience/boomer.wav
sound/ambience/flies.wav
models/pi_tree1.mdl
models/v_bloody_zombie_hands.mdl
models/zomhans.mdl
models/re_deadguy_3.mdl
