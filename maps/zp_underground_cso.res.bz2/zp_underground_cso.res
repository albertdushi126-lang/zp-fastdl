// zp_underground_cso.res - created with RESGen v2.0 BETA 2.
// RESGen is made by Jeroen "ShadowLord" Bogers.
// For more info go to http://resgen.hltools.com
// or E-mail me at resgen@hltools.com.

// .res entries (27):
react.wad
cs_assault.wad
cs_bdog.wad
cstrike.wad
halflife.wad
decals.wad
es_trinity.wad
models/zp_underground_cso/lampa_yl.mdl
models/zp_underground_cso/poezd4.mdl
models/zp_underground_cso/barricade_02.mdl
models/zp_underground_cso/karton_box.mdl
models/zp_underground_cso/norm_junk01.mdl
models/zp_underground_cso/norm_junk02.mdl
models/react_map/x_pc.mdl
models/zp_underground_cso/bulb.mdl
models/zp_underground_cso/vending_machine.mdl
models/zp_underground_cso/indoor01a.mdl
models/zp_underground_cso/geo_comp_mon.mdl
models/zp_underground_cso/geo_comp_klava.mdl
models/zp_underground_cso/buzz_kreslo.mdl
models/zp_underground_cso/dead_01.mdl
models/zp_underground_cso/sodamachine01.mdl
models/zp_underground_cso/dead_02.mdl
models/zp_underground_cso/fence_01.mdl
models/zp_underground_cso/light_04.mdl
models/zp_underground_cso/sink_small.mdl
models/zp_underground_cso/toilet_short.mdl
