models/zp_models/zp_nature/zp_desert01.mdl
models/zp_models/zp_junk/zp_boxes.mdl
models/zp_models/zp_street/zp_signalbox.mdl
models/zp_models/zp_light/zp_light01.mdl
models/zp_models/zp_junk/zp_junk02.mdl
models/zp_models/zp_junk/zp_junk01.mdl
models/zp_models/zp_junk/zp_fence02.mdl
models/zp_models/zp_light/zp_light02.mdl
models/zp_models/zp_nature/zp_palm01.mdl
models/zp_models/zp_nature/zp_rock01.mdl
models/zp_models/zp_nature/zp_rock02.mdl

sound/zp_sounds/zp_generator.wav
sound/zp_sounds/zp_aircraft.wav
sound/zp_sounds/zp_metal.wav
sound/zp_sounds/zp_wind2.wav
sound/zp_sounds/zp_strange_talk.wav
sound/zp_sounds/zp_city.wav
sound/zp_sounds/zp_wind.wav

overviews/zp_safeplace.bmp
overviews/zp_safeplace.txt

maps/zp_safeplace.txt
maps/zp_safeplace.res