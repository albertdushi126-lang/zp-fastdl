sound/ambience/ae_top.wav
sound/ambience/city_constr.wav
sound/ambience/Facility_01.wav
sound/ambience/Facility_03.wav
sound/ambience/trailer_wndinsidepark_loop.wav

cs_camouflage.wad
cs_hk.wad
dm_tunnel.wad
grid_cso.wad
tdm01.wad
zm_abyss2.wad
zs_double.wad
zs_lostcity.wad