// Made by Ard123 for de_supply
//WAD files are included into .bsp

maps/de_supply.res
maps/de_supply.txt
models/Ard123/barierka.mdl
models/Ard123/ciezarowka.mdl
models/Ard123/drzewo0.mdl
models/Ard123/drzewo1.mdl
models/Ard123/elektryk.mdl
models/Ard123/roslina.mdl
models/Ard123/trawa0.mdl
models/Ard123/swiatlo.mdl
overviews/de_supply.txt
overviews/de_supply.bmp
