// zp_outskirts.res - created with RESGen v2.0.2.
// RESGen is made by Jeroen "ShadowLord" Bogers,
// with serveral improvements and additions by Zero3Cool.
// For more info go to http://resgen.hltools.com

// .res entries (13):
gfx/env/desbk.tga
gfx/env/desdn.tga
gfx/env/desft.tga
gfx/env/deslf.tga
gfx/env/desrt.tga
gfx/env/desup.tga
models/zm_gorod_new/acunits01.mdl
models/zm_gorod_new/bulb.mdl
models/zm_gorod_new/by_barrels_pallet.mdl
models/zm_gorod_new/garbagecomposite002a.mdl
models/zm_gorod_new/pkgsgn02.mdl
models/zm_gorod_new/truck_old.mdl
models/zm_gorod_new/woodcrate.mdl
